

<?php $__env->startSection('content'); ?>
<div class="jumbotron text-left">
    <h1>Proizvodi za prodaju</h1>
</div>
<?php $__env->stopSection(); ?>
   
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lapp\resources\views/pages/services.blade.php ENDPATH**/ ?>