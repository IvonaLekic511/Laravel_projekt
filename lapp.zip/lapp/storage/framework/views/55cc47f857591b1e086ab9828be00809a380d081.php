

<?php $__env->startSection('content'); ?>
<br>
<div class="jumbotron text-left">
<a href="/posts" class="btn btn-dark">Idi nazad</a>
<hr>
<h1><?php echo e($post->title); ?></h1>
<div class="col-md-6 col-sm-6">
<img style="width:100%" src="/cover_images/<?php echo e($post->cover_image); ?>">
</div>
<div>
    <br>
    <?php echo $post->body; ?>

</div>
<br>
<small><b>Datum pisanja:</b> <?php echo e($post->created_at); ?> <b>Napisao korisnik:</b> <?php echo e($post->user['name']); ?></small>
<hr>
<?php if(!Auth::guest()): ?>
 <?php if(Auth::user()->id == $post->user_id): ?>
  <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

  <?php echo e(Form::hidden('_method', 'DELETE')); ?>


  <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-dark">Uredi</a> <?php echo e(Form::submit('Izbriši', ['class' => 'btn btn-danger'])); ?>

  <?php echo Form::close(); ?>

  </div>
 <?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lapp\resources\views/posts/show.blade.php ENDPATH**/ ?>