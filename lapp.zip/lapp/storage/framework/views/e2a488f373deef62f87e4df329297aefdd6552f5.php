
<?php $__env->startSection('content'); ?>
</br>
<div class="jumbotron text-left">
<h1>Napiši recenziju</h1>
<?php echo e(Form::open(array('action' => 'RecenzijesController@store'))); ?>

<div class="form-group">
        <?php echo Form::label('title', 'Title:', ['class' => 'col-lg-2 control-label']); ?>

        <div class="col-lg-10">
            <?php echo Form::text('title', $value = null, ['class' => 'form-control', 'placeholder' => 'Title']); ?>

        </div>
    </div>
<div class="form-group">
        <?php echo Form::label('body', 'Body', ['class' => 'col-lg-2 control-label']); ?>

        <div class="col-lg-10">
            <?php echo Form::textarea('body', $value = null, ['id' => 'article-ckeditor', 'class' => 'form-control', 'rows' => 5, 'placeholder' => 'Body text']); ?>

        </div>
    </div>
    &ensp; &nbsp; <?php echo e(Form::submit('Potvrdi', ['class' =>'btn btn-dark'])); ?>

    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lapp\resources\views/recenzijes/create.blade.php ENDPATH**/ ?>