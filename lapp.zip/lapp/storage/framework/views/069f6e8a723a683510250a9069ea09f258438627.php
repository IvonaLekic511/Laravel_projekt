

<?php $__env->startSection('content'); ?>
</br>
<div class="jumbotron text-left">
<h1><?php echo e($recenzije->title); ?></h1>
<div>
    <?php echo $recenzije->body; ?>

</div>
<hr>
<small>Datum pisanja <?php echo e($recenzije->created_at); ?></small>
</br>
</br>
<a href="/recenzijes" class="btn btn-dark">Nazad</a>
<hr>
<a href="/recenzijes/<?php echo e($recenzije->id); ?>/edit" class="btn btn-dark">Uredi</a>
<?php echo e(Form::open(array('action' => ['RecenzijesController@destroy', $recenzije->id]))); ?>

<?php echo e(Form::hidden('_method', 'DELETE')); ?>

<?php echo e(Form::submit('Izbriši', ['class' =>'btn btn-danger'])); ?>

<?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lapp\resources\views/recenzijes/show.blade.php ENDPATH**/ ?>