

<?php $__env->startSection('content'); ?>
</br>
<div class="jumbotron text-left">

<?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->type == 'admin' ||Auth::user()->type == 'normal_user'): ?>
        <h1>~Recenzije~</h1> <h5> <br><a href="/recenzijes/create" class="btn btn-dark"> Napiši novu recenziju </a> </h5>
        <?php endif; ?>
<?php endif; ?>
    <?php if(count($recenzijes) > 0): ?>
       <?php $__currentLoopData = $recenzijes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recenzije): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <br>
           <div class ="card card-body bg-light"
                <h3><a href="/recenzijes/<?php echo e($recenzije->id); ?>"><?php echo e($recenzije->title); ?></a></h3>
                <small>Datum pisanja <?php echo e($recenzije->created_at); ?></small>
           </div>

       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    <?php else: ?>
       <p>Trenutno nema recenzija.</p>
    <?php endif; ?>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lapp\resources\views/recenzijes/index.blade.php ENDPATH**/ ?>