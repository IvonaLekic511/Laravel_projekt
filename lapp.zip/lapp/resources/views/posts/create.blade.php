@extends('layouts.app')

@section('content')
<div class="jumbotron text-left">
   <h1>~Napiši ideju~ </h1>
   <br>
    {!! Form::open(['action' => 'PostsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
        <div class="form-group">
            {{Form::label('title', 'Naslov')}}
            {{Form::text('title', '', ['class' => 'form-control', 'placeholder' => 'Naslov'])}}
        </div>
        <div class="form-group">
                {{Form::label('body', 'Tekst')}}
                {{Form::textarea('body', '', ['id' => 'article-ckeditor', 'class' => 'form-control', 'placeholder' => 'Unesite željeni tekst'])}}
        </div>
        <div class="form-group">
                {{Form::file('cover_image')}}
        </div>
            {{Form::submit('Potvrdi', ['class'=>'btn btn-dark'])}}
            {!! Form::close() !!}
    </div>
@endsection