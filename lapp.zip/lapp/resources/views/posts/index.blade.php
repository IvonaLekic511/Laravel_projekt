@extends('layouts.app')

@section('content')
<div class="jumbotron text-left">
    <h1>~Ideje poklona~</h1>
    <br>
    @if(count($posts) > 0)
        @foreach($posts as $post)
            
                <div class="row">
                    <div class="col-md-4 col-sm-4">
                        <img style="width:100%" src="cover_images/{{$post->cover_image}}">
                    </div>
                    <div class ="card card-body bg-light"
                        <h3><a href="/posts/{{$post->id}}">{{$post->title}}</a></h3>
                        <small><b>Datum pisanja:</b> {{$post->created_at}} <b>Napisao korisnik:</b> {{$post->user['name']}}</small>
                    </div>
                </div>
                <hr>
        @endforeach
        {{$posts->links()}}
    @else
        <p>Trenutno nema objava.</p>
    @endif
</div>
@endsection