@extends('layouts.app')

@section('content')
<br>
<div class="jumbotron text-left">
<a href="/posts" class="btn btn-dark">Idi nazad</a>
<hr>
<h1>{{$post->title}}</h1>
<div class="col-md-6 col-sm-6">
<img style="width:100%" src="/cover_images/{{$post->cover_image}}">
</div>
<div>
    <br>
    {!!$post->body!!}
</div>
<br>
<small><b>Datum pisanja:</b> {{$post->created_at}} <b>Napisao korisnik:</b> {{$post->user['name']}}</small>
<hr>
@if(!Auth::guest())
 @if(Auth::user()->id == $post->user_id)
  {!!Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'pull-right'])!!}
  {{Form::hidden('_method', 'DELETE')}}

  <a href="/posts/{{$post->id}}/edit" class="btn btn-dark">Uredi</a> {{Form::submit('Izbriši', ['class' => 'btn btn-danger'])}}
  {!!Form::close()!!}
  </div>
 @endif
@endif
@endsection
