@extends('layouts.app')

@section('content')
<div class="jumbotron text-center">
        <h1  style=" border-style: solid; font-family: Nunito;
        border-width: 0px 0px 2px 0px;">~ G i f t a d o ~</h1>
        <br>
       
        <div class="jumbotron p-4 p-md-5 text-white" style="background-color:#03191E;">
                <div class="col-md-6 px-0">
                  <h1 class="display-4" style="font-family: Nunito;">Želite poseban poklon?</h1>
                  <p class="lead my-3" >Na našoj stranici imate mogućnost naći razne ideje kako sami da napravite poklon za voljenu osobu ili ukoliko ipak niste tako kreativni imate mogućnost naručiti neki od ponuđenih proizvoda</p>
                  <p class="lead my-3" >Ukoliko želite objaviti neku novu ideju ili kupiti neki proizvod potrebno je da se prijavite. </p>
                </div>
              </div>
              <p><a class="btn btn-outline-dark btn-lg" href="/login" role="button"> Prijava </a>
                <a class="btn btn-outline-dark btn-lg" href="/register" role="button">Registracija</a></p>
        </div>
<div  class="jumbotron text-center">
        <h1  style=" border-style: solid;
        border-width: 0px 0px 2px 0px;">~Pregledaj ideje poklona~</h1>
        <br>
        <div > <img style="margin:auto; width:80%; height:500px; display:block" src="https://i.pinimg.com/564x/5f/83/93/5f839309fa684d3438753d581a78423f.jpg"></div>
        <h3>Ukoliko želite pogledati ideje poklona kliknite <a href="/posts"> OVDJE </a>.</h3>

</div>


<div  class="jumbotron text-center">
         <h1  style=" border-style: solid;
        border-width: 0px 0px 2px 0px;">Proizvodi za prodaju</h1>
        <br>
                <img class="mySlides" style="margin:auto; width:60%; height:650px; display:block" src="https://i.pinimg.com/564x/ef/01/95/ef01951487c11ded364f606a8fd2858a.jpg">
                <img class="mySlides" style="margin:auto; width:60%; height:650px; display:block" src="https://i.pinimg.com/564x/44/ae/ec/44aeec190036b51e4ca819d77d685d58.jpg">
                <img class="mySlides" style="margin:auto; width:60%; height:650px; display:block" src="https://i.pinimg.com/564x/2b/3c/e9/2b3ce9b2a119c222ef264aeb2ed65234.jpg">
                <img class="mySlides" style="margin:auto; width:60%; height:650px; display:block" src="https://i.pinimg.com/564x/a9/86/bb/a986bb1c0f4dedd0a2dc96de2112d61a.jpg">
            
                        <script>
                                var slideIndex = 0;
                        carousel();

                        function carousel() {
                        var i;
                        var x = document.getElementsByClassName("mySlides");
                        for (i = 0; i < x.length; i++) {
                        x[i].style.display = "none"; 
                        }
                        slideIndex++;
                        if (slideIndex > x.length) {slideIndex = 1} 
                        x[slideIndex-1].style.display = "block"; 
                        setTimeout(carousel, 2000); // Change image every 2 seconds
                        }
                        </script>
      
</div>


<div class="jumbotron text-center">
                @auth
                @if(Auth::user()->type == 'admin')
                 <a class="btn btn-success btn-lg" href="/users">Korisnici</a>
                @endif
                @endauth 
                 
                
                </div>
@endsection