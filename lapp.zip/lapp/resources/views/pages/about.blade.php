@extends('layouts.app')



@section('content')

</br>

<div class="jumbotron text-left">
        <h1>~Kontakt~</h1>
<br>
<h4>Ukoliko imate nekih pitanja, slobodno nam se javite!</h4>

<br>
  <ul class="list-group">

        

              <li class="list-group-item" style="text-align:left">Broj mobitela : <b>063894125</b></li>

              <li class="list-group-item" style="text-align:left">E-mail adresa : <b>giftado@gmail.com</b></li>
   

  </ul>       
</div>


@endsection 