@extends('layouts.app')

@section('content')
<div class="jumbotron text-left">
    <h1>Proizvodi za prodaju</h1>
</div>
@endsection
   