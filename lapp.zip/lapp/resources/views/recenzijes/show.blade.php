@extends('layouts.app')

@section('content')
</br>
<div class="jumbotron text-left">
<h1>{{$recenzije->title}}</h1>
<div>
    {!!$recenzije->body!!}
</div>
<hr>
<small>Datum pisanja {{$recenzije->created_at}}</small>
</br>
</br>
<a href="/recenzijes" class="btn btn-dark">Nazad</a>
<hr>
<a href="/recenzijes/{{$recenzije->id}}/edit" class="btn btn-dark">Uredi</a>
{{Form::open(array('action' => ['RecenzijesController@destroy', $recenzije->id])) }}
{{Form::hidden('_method', 'DELETE')}}
{{Form::submit('Izbriši', ['class' =>'btn btn-danger'])}}
{!!Form::close()!!}
</div>
@endsection
