@extends('layouts.app')

@section('content')
</br>
<div class="jumbotron text-left">

@auth
        @if(Auth::user()->type == 'admin' ||Auth::user()->type == 'normal_user')
        <h1>~Recenzije~</h1> <h5> <br><a href="/recenzijes/create" class="btn btn-dark"> Napiši novu recenziju </a> </h5>
        @endif
@endauth
    @if(count($recenzijes) > 0)
       @foreach($recenzijes as $recenzije)
       <br>
           <div class ="card card-body bg-light"
                <h3><a href="/recenzijes/{{$recenzije->id}}">{{$recenzije->title}}</a></h3>
                <small>Datum pisanja {{$recenzije->created_at}}</small>
           </div>

       @endforeach
        
    @else
       <p>Trenutno nema recenzija.</p>
    @endif
        </div>
@endsection