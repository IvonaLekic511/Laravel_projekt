<?php

use App\Product;
use Illuminate\Database\Seeder;

class ProductsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
  
        Product::create([
            'name' => 'Svijeća',
            'slug' => 'Mirisna svijeća',
            'details' => 'Svijeća u tegli sa lavandom',
            'price' => 5,
            'shipping_cost' => 2,
            'description' => 'Mirisna svijeća sa cvijetom lavande',
            'category_id' => 1,
            'brand_id' => 2,
            'image_path' => 'svijeca.jpg'
        ]);

        Product::create([
            'name' => 'Čestitka',
            'slug' => 'Čestitka za rođendan',
            'details' => 'Papir za recikliranje,format A6',
            'price' => 3,
            'shipping_cost' => 0,
            'description' => 'Čestitka',
            'category_id' => 2,
            'brand_id' => 1,
            'image_path' => 'cestitka.jpg'
        ]);

        Product::create([
            'name' => 'Kutija za poklone',
            'slug' => 'Kutija',
            'details' => 'širina 50 cm dužina 80 cm',
            'price' => 8,
            'shipping_cost' => 1.50,
            'description' => 'Kutija za poklone',
            'category_id' => 3,
            'brand_id' => 3,
            'image_path' => 'kutija.jpg'
        ]);

        Product::create([
            'name' => 'Stalak za ključeve',
            'slug' => 'Stalak',
            'details' => 'stalak za 6 ključeva',
            'price' => 10,
            'shipping_cost' => 2,
            'description' => 'Stalak za ključeve',
            'category_id' => 4,
            'brand_id' => 4,
            'image_path' => 'stalak.jpg'
        ]);

        Product::create([
            'name' => 'Set za kuhinju',
            'slug' => 'Set',
            'details' => 'mutilica,kutljaca..',
            'price' => 15.99,
            'shipping_cost' => 2,
            'description' => 'Poklon set za kuhinju',
            'category_id' => 5,
            'brand_id' => 4,
            'image_path' => 'set.jpg'
        ]);

        Product::create([
            'name' => 'Igračka lisica',
            'slug' => 'Pletena igračka',
            'details' => 'Ručno rađena igračka',
            'price' => 20,
            'shipping_cost' => 5,
            'description' => 'Igračka lisica,ručno rađena',
            'category_id' => 2,
            'brand_id' => 5,
            'image_path' => 'lisica.jpg'
        ]);
    }
}
