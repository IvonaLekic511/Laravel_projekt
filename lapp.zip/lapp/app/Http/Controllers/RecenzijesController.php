<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Recenzije;
use DB;

class RecenzijesController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth' , ['except' => ['index', 'show']]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $recenzijes = Recenzije::orderBy('created_at','desc')->paginate(8);
        return view('recenzijes.index')->with('recenzijes', $recenzijes);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('recenzijes.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'title' => 'required',
            'body' => 'required',
            
        ]);

      // Handle File Upload
      if($request->hasFile('cover_image')){
        // Get filename with the extension
        $filenameWithExt = $request->file('cover_image')->getClientOriginalName();
        // Get just filename
        $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
        // Get just ext
        $extension = $request->file('cover_image')->getClientOriginalExtension();
        // Filename to store
        $fileNameToStore= $filename.'_'.time().'.'.$extension;
        // Upload Image
        $path = $request->file('cover_image')->storeAs('public/cover_images', $fileNameToStore);
    
    
    
    } 
         // Create Post
         $recenzije = new Recenzije;
         $recenzije->title = $request->input('title');
         $recenzije->body = $request->input('body');
         $recenzije->user_id = auth()->user()->id;
         
         $recenzije->save();
 
         return redirect('/recenzijes')->with('success', 'Uspješno ste kreirali objavu.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $recenzije = Recenzije::find($id);
        return view('recenzijes.show')->with('recenzije', $recenzije);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $recenzije = Recenzije::find($id);
    //Check for correct user 
    if(auth()->user()->id !==$recenzije->user_id){
          return redirect('/recenzijes')->with('error', 'Nemate prava uređivati objave drugih korisnika');

    }

        return view('recenzijes.edit')->with('recenzije', $recenzije);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'title' => 'required',
            'body' => 'required',
            
        ]);

         // Handle File Upload
      if($request->hasFile('cover_image')){
        // Get filename with the extension
        $filenameWithExt = $request->file('cover_image')->getClientOriginalName();
        // Get just filename
        $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
        // Get just ext
        $extension = $request->file('cover_image')->getClientOriginalExtension();
        // Filename to store
        $fileNameToStore= $filename.'_'.time().'.'.$extension;
        // Upload Image
        $path = $request->file('cover_image')->storeAs('public/cover_images', $fileNameToStore);
    } 

         // Create Post
         $recenzije = Recenzije::find($id);
         $recenzije->title = $request->input('title');
         $recenzije->body = $request->input('body');
         
         $recenzije->save();
 
         return redirect('/recenzijes')->with('success', 'Uspješno ste uredili objavu');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $recenzije = Recenzije::find($id);
    //Check for correct user 
    if(auth()->user()->id !==$recenzije->user_id){
        return redirect('/recenzijes')->with('error', 'Nemate prava brisati objave drugih korisnika');

    }

   

        $recenzije->delete();
        return redirect('/recenzijes')->with('success', 'Uspješno ste izbrisali objavu.');
    }
}